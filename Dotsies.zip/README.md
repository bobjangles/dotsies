# dotsies


========

# Dotsies for Firefox

This tool aims to provide in-broswer translation from standard fonts into dotsies font, via firefox add-on. 

More information about dotsies was once available via dotsies.org, but this has since been removed. 


>>>>>>> 465e148 (v1 readme)
